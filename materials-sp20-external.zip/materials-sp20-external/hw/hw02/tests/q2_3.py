test = {'name': 'q2_3', 'points': 1, 'suites': [{'cases': [], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
