test = {   'name': 'q4_2',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(cumulative_sum_answer) == int\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> 1 <= cumulative_sum_answer <= 3\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
