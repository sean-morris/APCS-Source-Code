test = {   'name': 'q5_1',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> # Hint: the average is between the shortest andthe longest;\n>>> shortest <= average <= longest\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
