test = {   'name': 'q5_4',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> 15 <= average_error <= 25\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
