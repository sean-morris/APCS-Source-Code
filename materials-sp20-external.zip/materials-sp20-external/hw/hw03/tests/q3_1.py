test = {   'name': 'q3_1',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> # Make sure you assing histogram_column_x to either 1 or 2!;\n>>> type(histogram_column_x) == int\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> histogram_column_x == 1 or histogram_column_x == 2\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
