test = {   'name': 'q4_3',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> boston_under_10 >= 0 and boston_under_10 <= 100\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> manila_under_10 >= 0 and manila_under_10 <= 100\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
