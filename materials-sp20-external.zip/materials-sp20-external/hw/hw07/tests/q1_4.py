test = {   'name': 'q1_4',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(reasonable_test_statistics) == np.ndarray\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(reasonable_test_statistics) >0\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
