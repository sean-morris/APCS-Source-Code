test = {   'name': 'q2_3',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> 1000 <= true_percentage_intervals <= 10000\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
