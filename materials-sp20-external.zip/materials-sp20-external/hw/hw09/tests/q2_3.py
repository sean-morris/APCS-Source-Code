test = {   'name': 'q2_3',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> len(example_estimates) == 10000\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> 850 < np.mean(example_estimates) < 1100\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.count_nonzero(np.diff(example_estimates)) >= 1\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
