test = {   'name': 'q3_1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> type(left_end_1) in set([float, np.float32, np.float64]) and type(right_end_1) in set([float, np.float32, np.float64])\nTrue',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
