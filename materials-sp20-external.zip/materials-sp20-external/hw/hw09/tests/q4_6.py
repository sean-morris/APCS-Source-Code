test = {   'name': 'q4_6',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> type(sample_mean_sd_statements) == np.ndarray\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
