test = {   'name': 'q1_17',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> type(same_parameters) == bool\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
