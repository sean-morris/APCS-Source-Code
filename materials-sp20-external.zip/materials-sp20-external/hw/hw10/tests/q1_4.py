test = {   'name': 'q1_4',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> np.isclose(correlation([1,2,3], [4,5,6]), .9999999)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
