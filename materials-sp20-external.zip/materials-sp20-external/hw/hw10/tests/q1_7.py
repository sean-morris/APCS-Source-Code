test = {   'name': 'q1_7',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> # The returned array should be of length 2;\n>>> len(parameters) == 2\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
