test = {   'name': 'q1_9',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> # The returned array should be length 2;\n>>> len(parameters_su) == 2\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
