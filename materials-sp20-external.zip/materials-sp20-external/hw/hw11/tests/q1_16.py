test = {   'name': 'q1_16',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> type(greatest_career_length_residual) == str\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
