test = {   'name': 'q1_5',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> sorted_coordinates = coordinates.sort("school");\n'
                                               '>>> classify(sorted_coordinates.row(29), 3, train) == three_classify(sorted_coordinates.row(29))\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
